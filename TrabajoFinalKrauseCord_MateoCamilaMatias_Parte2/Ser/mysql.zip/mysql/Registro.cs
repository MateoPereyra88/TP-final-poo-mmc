﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ser.mysql
{
  
    
    public class Registro
    {
        public string nombre { get; set; }
        public string contraseña { get; set; }
            
        public Registro() { }
        public Registro(string nombre, string contraseña)
        {
            this.contraseña = contraseña;
            this.nombre = nombre;
        }
    }
}
