﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using MySql.Data.MySqlClient;

namespace Ser.mysql
{
    public class Funciones
    {
        public static int Agregar(Registro add)
        {
            int retorno = 0;
            MySqlCommand comando = new MySqlCommand(String.Format("insert into Registro(nombre,contraseña) values ('{0}', '{1}'))", add.contraseña, add.nombre), Conexion.obtenerConexion());
            retorno = comando.ExecuteNonQuery();
            return retorno;
        }
    }
}
